make sure to type 'npm i' before proceeding, so all the packages will be installed automatically.
